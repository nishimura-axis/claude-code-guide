---
title: Welcome
type: fleeting
updated: 2026-04-02
---

# Vault スターターキットへようこそ

このVaultには以下が含まれています：

## 含まれているもの

### 広告講義コンテキスト（20_Context/AXIS/Ads/）
- [[_Overview|アド事業部 Overview]]
- [[Lecture_01_アドアフィ基礎（事業構造・指標・導線）|Lecture 01: アドアフィ基礎]]
- [[Lecture_02_媒体別アカウント構造|Lecture 02: 媒体別アカウント構造]]
- [[Lecture_03_ピクセルとCV計測の基礎|Lecture 03: ピクセルとCV計測]]
- [[Lecture_04_出稿業務の基礎|Lecture 04: 出稿業務]]
- [[Lecture_05_トッププレイヤーの1日の業務の流れ|Lecture 05: 運用者の1日]]
- [[Lecture_06_競合分析とリサーチの考え方|Lecture 06: 競合分析とリサーチ]]
- [[Lecture_07_運用データ分析と課題発見の考え方|Lecture 07: 運用データ分析]]
- [[Lecture_08_静止画CR基礎|Lecture 08: 静止画CR基礎]]
- [[Lecture_09_記事LPの基礎と構成|Lecture 09: 記事LPの基礎と構成]]

### テンプレート（60_Templates/）
新規ノート作成時に使えるテンプレートが16種類入っています。

## 次にやること

1. Claude Code のセットアップが終わっているか確認
2. このノートを読んだら、00_Inbox から適切なフォルダに移動してOK
3. 日々の作業ログは 07_DailyLog/ に書く
